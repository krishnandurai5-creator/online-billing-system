from .validators import ValidationError, validate_quantity, MAX_QTY
from .customers import get_customer
from .products import get_product

GST_RATE = 0.18
DISCOUNT_RATE = 0.05
DISCOUNT_THRESHOLD = 1000


def add_to_cart(conn, customer_id, product_id, quantity):
    customer = get_customer(conn, customer_id)
    product = get_product(conn, product_id)
    quantity = validate_quantity(quantity)
    if not product["available"]:
        raise ValidationError("This product is not available.")
    row = conn.execute("SELECT quantity FROM cart WHERE customer_id=? AND product_id=?",
                       (customer["customer_id"], product["product_id"])).fetchone()
    new_qty = quantity + (row["quantity"] if row else 0)
    if new_qty > MAX_QTY:
        raise ValidationError(f"Maximum {MAX_QTY} of one product per invoice.")
    conn.execute("INSERT OR REPLACE INTO cart VALUES (?, ?, ?)",
                 (customer["customer_id"], product["product_id"], new_qty))
    conn.commit()


def remove_from_cart(conn, customer_id, product_id):
    get_customer(conn, customer_id)
    cur = conn.execute("DELETE FROM cart WHERE customer_id=? AND product_id=?",
                       (int(customer_id), int(product_id)))
    if cur.rowcount == 0:
        raise ValidationError("That product is not in the cart.")
    conn.commit()


def cart_lines(conn, customer_id):
    return conn.execute(
        "SELECT p.product_id, p.name, c.quantity, p.price, c.quantity * p.price AS amount "
        "FROM cart c JOIN products p ON p.product_id = c.product_id "
        "WHERE c.customer_id = ? ORDER BY p.product_id", (customer_id,)).fetchall()


def calculate_totals(lines):
    """Discount 5% when subtotal >= 1000; GST 18% on the discounted amount."""
    subtotal = round(sum(line["amount"] for line in lines), 2)
    discount = round(subtotal * DISCOUNT_RATE, 2) if subtotal >= DISCOUNT_THRESHOLD else 0.0
    gst = round((subtotal - discount) * GST_RATE, 2)
    total = round(subtotal - discount + gst, 2)
    return {"subtotal": subtotal, "discount": discount, "gst": gst, "total": total}


def view_cart(conn, customer_id):
    customer = get_customer(conn, customer_id)
    lines = cart_lines(conn, customer["customer_id"])
    return lines, calculate_totals(lines)
