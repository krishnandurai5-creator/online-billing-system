import re

CATEGORIES = ["Electronics", "Groceries", "Stationery", "Services"]
PAYMENT_MODES = ["Cash", "UPI", "Card"]
MAX_QTY = 100


class ValidationError(Exception):
    """Raised when user input or a business rule is violated."""


def validate_name(value):
    value = (value or "").strip()
    if len(value) < 2 or len(value) > 50:
        raise ValidationError("Name must be 2 to 50 characters long.")
    return value


def validate_email(value):
    value = (value or "").strip().lower()
    if not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", value):
        raise ValidationError("Email address is not valid.")
    return value


def validate_phone(value):
    value = (value or "").strip()
    if not re.fullmatch(r"\d{10}", value):
        raise ValidationError("Phone number must be exactly 10 digits.")
    return value


def validate_price(value):
    try:
        price = float(value)
    except (TypeError, ValueError):
        raise ValidationError("Price must be a number greater than 0.")
    if price <= 0:
        raise ValidationError("Price must be a number greater than 0.")
    return round(price, 2)


def validate_quantity(value):
    try:
        qty = int(value)
    except (TypeError, ValueError):
        raise ValidationError(f"Quantity must be between 1 and {MAX_QTY}.")
    if qty < 1 or qty > MAX_QTY:
        raise ValidationError(f"Quantity must be between 1 and {MAX_QTY}.")
    return qty


def validate_id(value, label="ID"):
    try:
        number = int(value)
    except (TypeError, ValueError):
        raise ValidationError(f"{label} must be a positive whole number.")
    if number < 1:
        raise ValidationError(f"{label} must be a positive whole number.")
    return number


def validate_category(value):
    for cat in CATEGORIES:
        if (value or "").strip().lower() == cat.lower():
            return cat
    raise ValidationError("Category must be one of: " + ", ".join(CATEGORIES) + ".")


def validate_payment_mode(value):
    for mode in PAYMENT_MODES:
        if (value or "").strip().lower() == mode.lower():
            return mode
    raise ValidationError("Payment mode must be one of: " + ", ".join(PAYMENT_MODES) + ".")
