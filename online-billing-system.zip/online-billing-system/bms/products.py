import sqlite3
from .validators import (ValidationError, validate_name, validate_category,
                         validate_price, validate_id)


def add_product(conn, name, category, price):
    name = validate_name(name)
    category = validate_category(category)
    price = validate_price(price)
    try:
        cur = conn.execute("INSERT INTO products (name, category, price) VALUES (?, ?, ?)",
                           (name, category, price))
    except sqlite3.IntegrityError:
        raise ValidationError(f"Product '{name}' already exists.")
    conn.commit()
    return cur.lastrowid


def list_products(conn):
    return conn.execute("SELECT * FROM products ORDER BY product_id DESC").fetchall()


def search_products(conn, keyword):
    like = f"%{(keyword or '').strip()}%"
    return conn.execute("SELECT * FROM products WHERE name LIKE ? OR category LIKE ? "
                        "ORDER BY product_id", (like, like)).fetchall()


def get_product(conn, product_id):
    product_id = validate_id(product_id, "Product ID")
    row = conn.execute("SELECT * FROM products WHERE product_id = ?", (product_id,)).fetchone()
    if row is None:
        raise ValidationError(f"Product {product_id} does not exist.")
    return row


def remove_product(conn, product_id):
    product = get_product(conn, product_id)
    in_unpaid = conn.execute(
        "SELECT 1 FROM invoice_items ii JOIN invoices i ON i.invoice_id = ii.invoice_id "
        "WHERE ii.product_id = ? AND i.status = 'Unpaid'", (product["product_id"],)).fetchone()
    if in_unpaid:
        raise ValidationError("Product is part of an unpaid invoice and cannot be removed.")
    conn.execute("DELETE FROM cart WHERE product_id = ?", (product["product_id"],))
    conn.execute("UPDATE products SET available = 0 WHERE product_id = ?", (product["product_id"],))
    conn.commit()
