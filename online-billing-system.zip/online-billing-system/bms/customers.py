import sqlite3
from .validators import (ValidationError, validate_name, validate_email,
                         validate_phone, validate_id)


def register_customer(conn, name, email, phone):
    name = validate_name(name)
    email = validate_email(email)
    phone = validate_phone(phone)
    try:
        cur = conn.execute("INSERT INTO customers (name, email, phone) VALUES (?, ?, ?)",
                           (name, email, phone))
    except sqlite3.IntegrityError:
        raise ValidationError("A customer with this email already exists.")
    conn.commit()
    return cur.lastrowid


def list_customers(conn):
    return conn.execute("SELECT * FROM customers ORDER BY customer_id").fetchall()


def get_customer(conn, customer_id):
    customer_id = validate_id(customer_id, "Customer ID")
    row = conn.execute("SELECT * FROM customers WHERE customer_id = ?", (customer_id,)).fetchone()
    if row is None:
        raise ValidationError(f"Customer {customer_id} does not exist.")
    return row
