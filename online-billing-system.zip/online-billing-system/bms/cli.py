from .database import get_connection
from .validators import ValidationError, CATEGORIES
from . import products, customers, cart, invoices

MENU = """
========== ONLINE BILLING SYSTEM ==========
  1. Add product            8. View cart
  2. List products          9. Remove item from cart
  3. Search products       10. Generate invoice
  4. Remove product        11. Invoice history
  5. Register customer     12. Record payment
  6. List customers        13. Cancel invoice
  7. Add item to cart       0. Exit
===========================================
"""


def _table_products(rows):
    print(f"{'ID':<4}{'Product':<22}{'Category':<13}{'Price':>9}  Status")
    for r in rows:
        print(f"{r['product_id']:<4}{r['name']:<22}{r['category']:<13}{r['price']:>9.2f}  "
              f"{'Available' if r['available'] else 'Removed'}")


def run(db_path="billing.db"):
    conn = get_connection(db_path)
    print(MENU)
    while True:
        try:
            choice = input("Enter choice: ").strip()
            if choice == "0":
                print("Goodbye!")
                break
            elif choice == "1":
                name = input("Product name: ")
                cat = input(f"Category ({'/'.join(CATEGORIES)}): ")
                price = input("Price (Rs.): ")
                print(f"Product added with ID {products.add_product(conn, name, cat, price)}.")
            elif choice == "2":
                _table_products(products.list_products(conn))
            elif choice == "3":
                _table_products(products.search_products(conn, input("Keyword (name/category): ")))
            elif choice == "4":
                products.remove_product(conn, input("Product ID: "))
                print("Product removed.")
            elif choice == "5":
                name = input("Name: ")
                email = input("Email: ")
                phone = input("Phone (10 digits): ")
                print(f"Customer registered with ID {customers.register_customer(conn, name, email, phone)}.")
            elif choice == "6":
                for c in customers.list_customers(conn):
                    print(f"{c['customer_id']:<4}{c['name']:<20}{c['email']:<26}{c['phone']}")
            elif choice == "7":
                cust = input("Customer ID: ")
                cart.add_to_cart(conn, cust, input("Product ID: "), input("Quantity: "))
                print("Item added to cart.")
            elif choice == "8":
                lines, t = cart.view_cart(conn, input("Customer ID: "))
                print(f"{'ID':<4}{'Product':<22}{'Qty':>4}{'Price':>10}{'Amount':>10}")
                for l in lines:
                    print(f"{l['product_id']:<4}{l['name']:<22}{l['quantity']:>4}{l['price']:>10.2f}{l['amount']:>10.2f}")
                print(f"Subtotal : Rs. {t['subtotal']:.2f}\nDiscount : Rs. {t['discount']:.2f}\n"
                      f"GST (18%): Rs. {t['gst']:.2f}\nTotal    : Rs. {t['total']:.2f}")
            elif choice == "9":
                cust = input("Customer ID: ")
                cart.remove_from_cart(conn, cust, input("Product ID: "))
                print("Item removed from cart.")
            elif choice == "10":
                inv = invoices.generate_invoice(conn, input("Customer ID: "))
                total = invoices.get_invoice(conn, inv)["total"]
                print(f"Invoice generated. Invoice ID {inv}, total Rs. {total:.2f}.")
            elif choice == "11":
                for inv in invoices.invoice_history(conn, input("Customer ID: ")):
                    pay = f" ({inv['payment_mode']})" if inv["payment_mode"] else ""
                    print(f"Invoice #{inv['invoice_id']} | {inv['customer_name']} | {inv['status']}{pay} "
                          f"| {inv['created_at']} | Total Rs. {inv['total']:.2f}")
                    print("   " + ", ".join(f"{i['quantity']} x {i['name']}"
                                            for i in invoices.invoice_items(conn, inv["invoice_id"])))
            elif choice == "12":
                inv = input("Invoice ID: ")
                invoices.mark_paid(conn, inv, input("Payment mode (Cash/UPI/Card): "))
                print("Payment recorded. Invoice marked as Paid.")
            elif choice == "13":
                invoices.cancel_invoice(conn, input("Invoice ID: "))
                print("Invoice cancelled.")
            else:
                print("Invalid choice. Please enter a number from the menu.")
        except ValidationError as err:
            print(f"Error: {err}")
        except (KeyboardInterrupt, EOFError):
            print("\nGoodbye!")
            break
    conn.close()
