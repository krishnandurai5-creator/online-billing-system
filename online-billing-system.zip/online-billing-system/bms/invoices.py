from datetime import datetime
from .validators import ValidationError, validate_id, validate_payment_mode
from .customers import get_customer
from .cart import cart_lines, calculate_totals


def generate_invoice(conn, customer_id, now=None):
    customer = get_customer(conn, customer_id)
    lines = cart_lines(conn, customer["customer_id"])
    if not lines:
        raise ValidationError("Your cart is empty. Add products before generating an invoice.")
    t = calculate_totals(lines)
    stamp = (now or datetime.now()).strftime("%Y-%m-%d %H:%M")
    cur = conn.execute(
        "INSERT INTO invoices (customer_id, created_at, subtotal, discount, gst, total) "
        "VALUES (?, ?, ?, ?, ?, ?)",
        (customer["customer_id"], stamp, t["subtotal"], t["discount"], t["gst"], t["total"]))
    invoice_id = cur.lastrowid
    for line in lines:
        conn.execute("INSERT INTO invoice_items VALUES (?, ?, ?, ?)",
                     (invoice_id, line["product_id"], line["quantity"], line["price"]))
    conn.execute("DELETE FROM cart WHERE customer_id = ?", (customer["customer_id"],))
    conn.commit()
    return invoice_id


def get_invoice(conn, invoice_id):
    invoice_id = validate_id(invoice_id, "Invoice ID")
    row = conn.execute("SELECT * FROM invoices WHERE invoice_id = ?", (invoice_id,)).fetchone()
    if row is None:
        raise ValidationError(f"Invoice {invoice_id} does not exist.")
    return row


def invoice_items(conn, invoice_id):
    return conn.execute(
        "SELECT p.name, ii.quantity, ii.unit_price FROM invoice_items ii "
        "JOIN products p ON p.product_id = ii.product_id WHERE ii.invoice_id = ?",
        (invoice_id,)).fetchall()


def invoice_history(conn, customer_id):
    customer = get_customer(conn, customer_id)
    return conn.execute(
        "SELECT i.*, c.name AS customer_name FROM invoices i JOIN customers c "
        "ON c.customer_id = i.customer_id WHERE i.customer_id = ? ORDER BY i.invoice_id",
        (customer["customer_id"],)).fetchall()


def mark_paid(conn, invoice_id, payment_mode):
    invoice = get_invoice(conn, invoice_id)
    mode = validate_payment_mode(payment_mode)
    if invoice["status"] != "Unpaid":
        raise ValidationError(f"Invoice {invoice['invoice_id']} is already {invoice['status']}.")
    conn.execute("UPDATE invoices SET status='Paid', payment_mode=? WHERE invoice_id=?",
                 (mode, invoice["invoice_id"]))
    conn.commit()


def cancel_invoice(conn, invoice_id):
    invoice = get_invoice(conn, invoice_id)
    if invoice["status"] != "Unpaid":
        raise ValidationError("Only invoices with status 'Unpaid' can be cancelled.")
    conn.execute("UPDATE invoices SET status='Cancelled' WHERE invoice_id=?",
                 (invoice["invoice_id"],))
    conn.commit()


def unpaid_invoices(conn):
    return conn.execute("SELECT * FROM invoices WHERE status='Unpaid' ORDER BY invoice_id").fetchall()
