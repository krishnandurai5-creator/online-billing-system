import unittest
from bms.database import get_connection
from bms.validators import *
from bms import products, customers, cart, invoices


def fresh():
    conn = get_connection(":memory:")
    products.add_product(conn, "Laptop Bag", "Electronics", 800)
    products.add_product(conn, "Notebook", "Stationery", 60)
    customers.register_customer(conn, "Meera Iyer", "meera@example.com", "9876543210")
    return conn


class TestValidators(unittest.TestCase):
    def test_email_invalid(self):
        with self.assertRaises(ValidationError): validate_email("bad-email")
    def test_email_valid_is_lowercased(self):
        self.assertEqual(validate_email("A@B.com"), "a@b.com")
    def test_phone_must_be_10_digits(self):
        with self.assertRaises(ValidationError): validate_phone("123")
        self.assertEqual(validate_phone("9876543210"), "9876543210")
    def test_price_rejects_zero_negative_and_text(self):
        for bad in (0, -5, "abc"):
            with self.assertRaises(ValidationError): validate_price(bad)
    def test_quantity_range(self):
        for bad in (0, 101, "x"):
            with self.assertRaises(ValidationError): validate_quantity(bad)
        self.assertEqual(validate_quantity("5"), 5)
    def test_category_is_normalised(self):
        self.assertEqual(validate_category("groceries"), "Groceries")
    def test_payment_mode(self):
        self.assertEqual(validate_payment_mode("upi"), "UPI")
        with self.assertRaises(ValidationError): validate_payment_mode("cheque")


class TestProducts(unittest.TestCase):
    def test_add_and_list(self):
        self.assertEqual(len(products.list_products(fresh())), 2)
    def test_duplicate_name_rejected_case_insensitive(self):
        with self.assertRaises(ValidationError): products.add_product(fresh(), "notebook", "Stationery", 10)
    def test_search_is_case_insensitive(self):
        self.assertEqual(len(products.search_products(fresh(), "LAPTOP")), 1)
    def test_remove_unbilled_product(self):
        c = fresh(); products.remove_product(c, 2)
        self.assertEqual(products.get_product(c, 2)["available"], 0)
    def test_cannot_remove_product_in_unpaid_invoice(self):
        c = fresh(); cart.add_to_cart(c, 1, 2, 1); invoices.generate_invoice(c, 1)
        with self.assertRaises(ValidationError): products.remove_product(c, 2)


class TestCustomers(unittest.TestCase):
    def test_register_returns_id(self):
        self.assertEqual(customers.register_customer(fresh(), "Ravi Kumar", "r@x.com", "9000000001"), 2)
    def test_duplicate_email_rejected_case_insensitive(self):
        with self.assertRaises(ValidationError): customers.register_customer(fresh(), "Other", "MEERA@example.com", "9000000001")
    def test_unknown_customer(self):
        with self.assertRaises(ValidationError): customers.get_customer(fresh(), 99)


class TestCart(unittest.TestCase):
    def test_totals_with_gst_no_discount(self):
        c = fresh(); cart.add_to_cart(c, 1, 2, 5)          # 300
        _, t = cart.view_cart(c, 1)
        self.assertEqual((t["subtotal"], t["discount"], t["gst"], t["total"]), (300, 0, 54, 354))
    def test_discount_at_1000_or_more(self):
        c = fresh(); cart.add_to_cart(c, 1, 1, 2)          # 1600
        _, t = cart.view_cart(c, 1)
        self.assertEqual((t["discount"], t["gst"], t["total"]), (80, 273.6, 1793.6))
    def test_quantity_limit_per_product(self):
        c = fresh(); cart.add_to_cart(c, 1, 2, 100)
        with self.assertRaises(ValidationError): cart.add_to_cart(c, 1, 2, 1)
    def test_removed_product_rejected(self):
        c = fresh(); products.remove_product(c, 2)
        with self.assertRaises(ValidationError): cart.add_to_cart(c, 1, 2, 1)
    def test_remove_from_cart(self):
        c = fresh(); cart.add_to_cart(c, 1, 2, 1); cart.remove_from_cart(c, 1, 2)
        self.assertEqual(len(cart.cart_lines(c, 1)), 0)


class TestInvoices(unittest.TestCase):
    def test_generate_stores_totals_and_clears_cart(self):
        c = fresh(); cart.add_to_cart(c, 1, 2, 5); i = invoices.generate_invoice(c, 1)
        self.assertEqual(invoices.get_invoice(c, i)["total"], 354)
        self.assertEqual(len(cart.cart_lines(c, 1)), 0)
    def test_empty_cart_rejected(self):
        with self.assertRaises(ValidationError): invoices.generate_invoice(fresh(), 1)
    def test_unknown_customer_rejected(self):
        with self.assertRaises(ValidationError): invoices.generate_invoice(fresh(), 9)
    def test_payment_flow(self):
        c = fresh(); cart.add_to_cart(c, 1, 2, 1); i = invoices.generate_invoice(c, 1)
        invoices.mark_paid(c, i, "UPI")
        inv = invoices.get_invoice(c, i)
        self.assertEqual((inv["status"], inv["payment_mode"]), ("Paid", "UPI"))
    def test_cancel_only_when_unpaid(self):
        c = fresh(); cart.add_to_cart(c, 1, 2, 1); i = invoices.generate_invoice(c, 1)
        invoices.mark_paid(c, i, "Cash")
        with self.assertRaises(ValidationError): invoices.cancel_invoice(c, i)
    def test_cancelled_invoice_cannot_be_paid(self):
        c = fresh(); cart.add_to_cart(c, 1, 2, 1); i = invoices.generate_invoice(c, 1)
        invoices.cancel_invoice(c, i)
        with self.assertRaises(ValidationError): invoices.mark_paid(c, i, "Cash")
    def test_history_and_unpaid_list(self):
        c = fresh(); cart.add_to_cart(c, 1, 2, 1); invoices.generate_invoice(c, 1)
        self.assertEqual(len(invoices.invoice_history(c, 1)), 1)
        self.assertEqual(len(invoices.unpaid_invoices(c)), 1)

if __name__ == "__main__":
    unittest.main()
